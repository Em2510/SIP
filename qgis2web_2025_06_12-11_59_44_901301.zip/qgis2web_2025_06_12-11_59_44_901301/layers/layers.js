var wms_layers = [];

var lyr_ortofotomapa_0 = new ol.layer.Tile({
                            source: new ol.source.TileWMS(({
                              url: "https://mapy.geoportal.gov.pl/wss/service/PZGIK/ORTO/WMS/StandardResolutionTime",
                              attributions: ' ',
                              params: {
                                "LAYERS": "Raster",
                                "TILED": "true",
                                "VERSION": "1.3.0"},
                            })),
                            title: 'ortofotomapa',
                            popuplayertitle: 'ortofotomapa',
                            opacity: 1.000000,
                            
                            
                          });
              wms_layers.push([lyr_ortofotomapa_0, 1]);
var format_sentinel_1 = new ol.format.GeoJSON();
var features_sentinel_1 = format_sentinel_1.readFeatures(json_sentinel_1, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:3857'});
var jsonSource_sentinel_1 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_sentinel_1.addFeatures(features_sentinel_1);
var lyr_sentinel_1 = new ol.layer.Vector({
                declutter: false,
                source:jsonSource_sentinel_1, 
                style: style_sentinel_1,
                popuplayertitle: 'sentinel',
                interactive: true,
                title: '<img src="styles/legend/sentinel_1.png" /> sentinel'
            });
var format_vmap_2 = new ol.format.GeoJSON();
var features_vmap_2 = format_vmap_2.readFeatures(json_vmap_2, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:3857'});
var jsonSource_vmap_2 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_vmap_2.addFeatures(features_vmap_2);
var lyr_vmap_2 = new ol.layer.Vector({
                declutter: false,
                source:jsonSource_vmap_2, 
                style: style_vmap_2,
                popuplayertitle: 'vmap',
                interactive: true,
                title: '<img src="styles/legend/vmap_2.png" /> vmap'
            });
var format_archiw_3 = new ol.format.GeoJSON();
var features_archiw_3 = format_archiw_3.readFeatures(json_archiw_3, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:3857'});
var jsonSource_archiw_3 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_archiw_3.addFeatures(features_archiw_3);
var lyr_archiw_3 = new ol.layer.Vector({
                declutter: false,
                source:jsonSource_archiw_3, 
                style: style_archiw_3,
                popuplayertitle: 'archiw',
                interactive: true,
                title: '<img src="styles/legend/archiw_3.png" /> archiw'
            });

lyr_ortofotomapa_0.setVisible(true);lyr_sentinel_1.setVisible(true);lyr_vmap_2.setVisible(true);lyr_archiw_3.setVisible(true);
var layersList = [lyr_ortofotomapa_0,lyr_sentinel_1,lyr_vmap_2,lyr_archiw_3];
lyr_sentinel_1.set('fieldAliases', {'Id': 'Id', 'gridcode': 'gridcode', 'Shape_Leng': 'Shape_Leng', 'Shape_Area': 'Shape_Area', 'wsk': 'wsk', 'nazwa': 'nazwa', });
lyr_vmap_2.set('fieldAliases', {'DLUG_BRZEG': 'DLUG_BRZEG', 'DLUGOSC': 'DLUGOSC', 'DOKLADNOSC': 'DOKLADNOSC', 'DOSTEPNOSC': 'DOSTEPNOSC', 'GLEBOKOSC': 'GLEBOKOSC', 'ISTNIENIE': 'ISTNIENIE', 'KAT_HYDRO': 'KAT_HYDRO', 'KAT_PLYWU': 'KAT_PLYWU', 'KAT_POJEMN': 'KAT_POJEMN', 'KAT_POLOZ': 'KAT_POLOZ', 'KAT_WODY': 'KAT_WODY', 'NAJW_WYS': 'NAJW_WYS', 'NAZWA': 'NAZWA', 'OBIEKT': 'OBIEKT', 'OPR_UPUST': 'OPR_UPUST', 'OPR_ZBURZ': 'OPR_ZBURZ', 'POCH_HYDRO': 'POCH_HYDRO', 'PRED_PRZEP': 'PRED_PRZEP', 'SREDNIA_GL': 'SREDNIA_GL', 'STAT_EKSPL': 'STAT_EKSPL', 'SZEROKOSC': 'SZEROKOSC', 'TAJNOSC': 'TAJNOSC', 'TYP_AKWED': 'TYP_AKWED', 'TYP_WYBRZ': 'TYP_WYBRZ', 'ZN_ORIENT': 'ZN_ORIENT', 'POWIERZCHN': 'POWIERZCHN', 'ID': 'ID', 'Shape_Leng': 'Shape_Leng', 'Shape_Area': 'Shape_Area', 'wsk': 'wsk', 'nazwa_1': 'nazwa_1', });
lyr_archiw_3.set('fieldAliases', {'Id': 'Id', 'Shape_Leng': 'Shape_Leng', 'Shape_Area': 'Shape_Area', 'wsk': 'wsk', 'Nazwa': 'Nazwa', });
lyr_sentinel_1.set('fieldImages', {'Id': 'TextEdit', 'gridcode': 'TextEdit', 'Shape_Leng': 'TextEdit', 'Shape_Area': 'TextEdit', 'wsk': 'TextEdit', 'nazwa': 'TextEdit', });
lyr_vmap_2.set('fieldImages', {'DLUG_BRZEG': 'TextEdit', 'DLUGOSC': 'TextEdit', 'DOKLADNOSC': 'TextEdit', 'DOSTEPNOSC': 'TextEdit', 'GLEBOKOSC': 'TextEdit', 'ISTNIENIE': 'TextEdit', 'KAT_HYDRO': 'TextEdit', 'KAT_PLYWU': 'TextEdit', 'KAT_POJEMN': 'TextEdit', 'KAT_POLOZ': 'TextEdit', 'KAT_WODY': 'TextEdit', 'NAJW_WYS': 'TextEdit', 'NAZWA': 'TextEdit', 'OBIEKT': 'TextEdit', 'OPR_UPUST': 'TextEdit', 'OPR_ZBURZ': 'TextEdit', 'POCH_HYDRO': 'TextEdit', 'PRED_PRZEP': 'TextEdit', 'SREDNIA_GL': 'TextEdit', 'STAT_EKSPL': 'TextEdit', 'SZEROKOSC': 'TextEdit', 'TAJNOSC': 'TextEdit', 'TYP_AKWED': 'TextEdit', 'TYP_WYBRZ': 'TextEdit', 'ZN_ORIENT': 'TextEdit', 'POWIERZCHN': 'TextEdit', 'ID': 'TextEdit', 'Shape_Leng': 'TextEdit', 'Shape_Area': 'TextEdit', 'wsk': 'TextEdit', 'nazwa_1': 'TextEdit', });
lyr_archiw_3.set('fieldImages', {'Id': 'TextEdit', 'Shape_Leng': 'TextEdit', 'Shape_Area': 'TextEdit', 'wsk': 'TextEdit', 'Nazwa': 'TextEdit', });
lyr_sentinel_1.set('fieldLabels', {'Id': 'inline label - visible with data', 'gridcode': 'inline label - visible with data', 'Shape_Leng': 'inline label - visible with data', 'Shape_Area': 'inline label - visible with data', 'wsk': 'inline label - visible with data', 'nazwa': 'inline label - always visible', });
lyr_vmap_2.set('fieldLabels', {'DLUG_BRZEG': 'inline label - visible with data', 'DLUGOSC': 'inline label - visible with data', 'DOKLADNOSC': 'inline label - visible with data', 'DOSTEPNOSC': 'inline label - visible with data', 'GLEBOKOSC': 'inline label - visible with data', 'ISTNIENIE': 'inline label - visible with data', 'KAT_HYDRO': 'inline label - visible with data', 'KAT_PLYWU': 'inline label - visible with data', 'KAT_POJEMN': 'inline label - visible with data', 'KAT_POLOZ': 'inline label - visible with data', 'KAT_WODY': 'inline label - visible with data', 'NAJW_WYS': 'inline label - visible with data', 'NAZWA': 'inline label - visible with data', 'OBIEKT': 'inline label - visible with data', 'OPR_UPUST': 'inline label - visible with data', 'OPR_ZBURZ': 'inline label - visible with data', 'POCH_HYDRO': 'inline label - visible with data', 'PRED_PRZEP': 'inline label - visible with data', 'SREDNIA_GL': 'inline label - visible with data', 'STAT_EKSPL': 'inline label - visible with data', 'SZEROKOSC': 'inline label - visible with data', 'TAJNOSC': 'inline label - visible with data', 'TYP_AKWED': 'inline label - visible with data', 'TYP_WYBRZ': 'inline label - visible with data', 'ZN_ORIENT': 'inline label - visible with data', 'POWIERZCHN': 'inline label - visible with data', 'ID': 'inline label - visible with data', 'Shape_Leng': 'inline label - visible with data', 'Shape_Area': 'inline label - visible with data', 'wsk': 'inline label - visible with data', 'nazwa_1': 'inline label - always visible', });
lyr_archiw_3.set('fieldLabels', {'Id': 'inline label - visible with data', 'Shape_Leng': 'inline label - visible with data', 'Shape_Area': 'inline label - visible with data', 'wsk': 'inline label - visible with data', 'Nazwa': 'inline label - always visible', });
lyr_archiw_3.on('precompose', function(evt) {
    evt.context.globalCompositeOperation = 'normal';
});